+++
description = "This be a hidden demo child plank"
hidden = true
tags = ["children", "the hidden"]
title = "plank 1-1-1-1-1 (hidden)"
+++
{{< piratify >}}