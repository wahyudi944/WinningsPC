+++
alwaysopen = false
description = "This is a demo child page"
tags = ["children", "non-hidden"]
title = "page 3"
weight = 30
+++

This is a demo child page.

## Subpages of this page

{{% children showhidden="true" %}}
