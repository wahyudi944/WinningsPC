+++
description = "List Rrresources shorrrtcode contained in a plank bundle"
title = "Resources"
[[resources]]
  name = 'MaybeTreasure.txt'
  src = 'MaybeTreasure.pir.txt'
+++
{{% resources /%}}

{{< piratify >}}