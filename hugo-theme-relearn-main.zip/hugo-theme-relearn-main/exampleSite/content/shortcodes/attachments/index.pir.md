+++
description = "Th' Attachments shorrrtcode displays a list o' files attached t' a plank"
hidden = "true"
title = "Attachments"
+++
{{< piratify >}}