+++
+++

You can define optional content in your overridden taxonomy page. As well you can define optional `title` and `singulartitle` that will override the values from your `hugo.toml` or of your translation files.

## Just an example heading

The TOC will contain this heading and the index headings below.