+++
title = "Image Effects"
weight = 5
+++
{{< piratify >}}