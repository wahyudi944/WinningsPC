+++
description = "Recipe t' create various documentat'n scrrreenshots"
title = "Scrrrenshots"
+++
{{< piratify >}}