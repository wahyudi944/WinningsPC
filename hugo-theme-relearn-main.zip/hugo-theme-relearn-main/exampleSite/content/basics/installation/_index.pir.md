+++
tags = ["documentat'n"]
title = "Installat'n"
weight = 15
+++
{{< piratify >}}