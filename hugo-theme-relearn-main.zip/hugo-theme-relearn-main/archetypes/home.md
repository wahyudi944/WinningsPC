+++
archetype = "home"
title = "{{ replace .Name "-" " " | title }}"
+++

This is a new home page.
